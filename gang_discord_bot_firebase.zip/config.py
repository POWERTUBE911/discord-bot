# قم بوضع رمز البوت (Token) الخاص بك هنا
# يجب أن تحصل على هذا الرمز من بوابة مطوري ديسكورد (Discord Developer Portal)
# تأكد من عدم مشاركة هذا الرمز مع أي شخص آخر!
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# بيانات اتصال Firebase Realtime Database (مستخلصة من ملف script.js)
# يرجى ملاحظة: قد تحتاج إلى إعداد قواعد أمان (Security Rules) في Firebase
# للسماح بالوصول للقراءة العامة (public read access) للبيانات.
FIREBASE_URL = "https://gang-war-2-default-rtdb.europe-west1.firebasedatabase.app"
FIREBASE_SECRET = None # لا نحتاج إلى سر في هذه الحالة لأننا نقرأ فقط، ولكن يمكن إضافته هنا إذا لزم الأمر.
