import discord
from discord.ext import commands
import json
import os

# تعريف البوت
# `command_prefix='!'` يعني أن الأوامر تبدأ بعلامة تعجب
# `intents=discord.Intents.default()` يمنح البوت الصلاحيات الأساسية
bot = commands.Bot(command_prefix='!', intents=discord.Intents.default())

# المسار إلى ملف البيانات
DATA_FILE = os.path.join(os.path.dirname(__file__), 'gang_data.json')

def calculate_level(points, rewards_levels):
    """تحسب مستوى العصابة بناءً على النقاط وقائمة المستويات."""
    # البحث عن أعلى مستوى تحققه النقاط
    level = 0
    for reward in rewards_levels:
        if points >= reward['points']:
            level = reward['level']
        else:
            # بما أن القائمة مرتبة، يمكننا التوقف عند أول مستوى لم يتحقق
            break
    return level

def get_gang_data():
    """تحميل ومعالجة بيانات العصابات من ملف JSON."""
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"خطأ: لم يتم العثور على ملف البيانات في المسار: {DATA_FILE}")
        return []
    except json.JSONDecodeError:
        print("خطأ: تعذر قراءة ملف JSON.")
        return []

    rewards_levels = data.get('rewards_levels', [])
    gangs = data.get('gangs', [])
    
    # تحديث النقاط والمستويات لغرض العرض التجريبي
    # (في البوت الحقيقي، سيتم جلب هذه البيانات من قاعدة بيانات حية)
    # نستخدم نفس الأرقام التي استخدمناها في data_processor.py للتناسق
    if gangs:
        gangs[0]['points'] = 150 # البلود
        gangs[1]['points'] = 30  # المافيا
        gangs[2]['points'] = 265 # القروف ستريت
        
    
    # حساب المستوى لكل عصابة
    for gang in gangs:
        gang['level'] = calculate_level(gang.get('points', 0), rewards_levels)
        
    # ترتيب العصابات حسب النقاط تنازليًا
    sorted_gangs = sorted(gangs, key=lambda g: g.get('points', 0), reverse=True)
    
    return sorted_gangs

@bot.event
async def on_ready():
    """يتم تشغيل هذه الدالة عند اتصال البوت بالديسكورد بنجاح."""
    print(f'البوت جاهز. تم تسجيل الدخول باسم: {bot.user}')
    print('--------------------------------------------------')

@bot.command(name='نقاط')
async def show_gang_points(ctx):
    """يعرض نقاط ومستوى جميع العصابات."""
    await ctx.send("جاري جلب بيانات العصابات...")
    
    gangs_data = get_gang_data()
    
    if not gangs_data:
        await ctx.send("عذرًا، لم أتمكن من جلب بيانات العصابات.")
        return

    # إنشاء رسالة Embed منسقة
    embed = discord.Embed(
        title="🏆 ترتيب العصابات الحالي 🏆",
        description="قائمة بجميع العصابات ونقاطها ومستوياتها.",
        color=discord.Color.gold() # لون ذهبي
    )
    
    # إضافة حقول لكل عصابة
    for index, gang in enumerate(gangs_data, 1):
        name = gang['name']
        points = gang['points']
        level = gang['level']
        
        # تنسيق الحقل المطلوب: اسم العصابة، تحتها عدد النقاط، تحتها مستوى العصابة
        field_value = (
            f"**النقاط:** {points}\n"
            f"**المستوى:** {level}"
        )
        
        # إضافة حقل لكل عصابة
        embed.add_field(
            name=f"{index}. {name}",
            value=field_value,
            inline=True # عرض الحقول بجانب بعضها البعض
        )

    embed.set_footer(text=f"آخر تحديث للبيانات: {discord.utils.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    
    # إرسال رسالة Embed
    await ctx.send(embed=embed)

# ملاحظة: يجب استبدال 'YOUR_BOT_TOKEN' برمز البوت الخاص بك
# سيتم إضافة ملف منفصل لرمز البوت في المرحلة التالية
from config import BOT_TOKEN

if __name__ == '__main__':
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("خطأ: يرجى تعديل ملف config.py وإضافة رمز البوت الخاص بك.")
    else:
        bot.run(BOT_TOKEN)
