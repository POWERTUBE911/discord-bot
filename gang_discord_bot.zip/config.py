# قم بوضع رمز البوت (Token) الخاص بك هنا
# يجب أن تحصل على هذا الرمز من بوابة مطوري ديسكورد (Discord Developer Portal)
# تأكد من عدم مشاركة هذا الرمز مع أي شخص آخر!
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# مثال:
# BOT_TOKEN = "MTIzNDU2Nzg5MDEyMzQ1Njc4O.ABCDEF.GHIJKLMNOPQRSTUVWXYZ"
